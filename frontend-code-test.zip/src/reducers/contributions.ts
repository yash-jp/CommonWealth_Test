import { Contributions } from '../types/contribution';

const contributions = (state: Contributions = {}) => state;

export default contributions;
